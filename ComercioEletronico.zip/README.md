# ComercioEletronico_V2
Projeto em Grails simulando uma loja virtual, com foco principal no desenvolvimento de views
